

To find the list of people we contacted, see:
https://docs.google.com/spreadsheet/ccc?key=0AhGnAxuBDhjmdDYwNzlZVE5SMkFsMjNBbGlaWkpNZ1E&usp=sharing

To obtain access to this file, send an email to:
nelle dot varoquaux at gmail dot com

