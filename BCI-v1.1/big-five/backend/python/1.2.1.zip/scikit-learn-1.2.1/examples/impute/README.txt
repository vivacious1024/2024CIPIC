.. _impute_examples:

Missing Value Imputation
------------------------

Examples concerning the :mod:`sklearn.impute` module.
